# HWPX 논문 작성 키트

AI 에이전트(Claude Code 등)로 한글 문서(.hwpx) 원고를 **안전하게 수정하고 검증**하기 위한 키트다. 논문·보고서처럼 이미 존재하는 hwpx를 고쳐 나가는 작업을 대상으로 한다.

## 왜 필요한가

hwpx를 AI에게 맡길 때 실제로 사고가 나는 지점은 정해져 있다.

- 에이전트가 원고 전체를 다시 만들어 덮어써서 **사람이 한글에서 직접 고친 내용이 사라진다.**
- 표를 건드렸더니 행이 통째로 재배치되거나 표가 다음 쪽으로 밀린다.
- 수정한 파일이 한글에서 **오류창도 없이 그냥 안 열린다.**
- 고쳤다고 보고받았지만 실제 문서가 어떻게 보이는지 아무도 확인하지 않았다.

이 키트는 위 네 가지를 각각 규칙·함정 목록·검증 스크립트로 막는다.

## 담긴 것

```
README.md                      ← 이 파일
mcp.json.example               ← MCP 서버 설정 템플릿
skills/hwpx-editing/
  SKILL.md                     ← 에이전트가 읽는 작업 규칙
  scripts/verify-hwpx.ps1      ← 한글에서 열리는지 판정 + PDF 변환
  scripts/render-pdf.ps1       ← PDF의 지정 페이지를 PNG로 렌더(육안 확인용)
```

MCP 서버 자체는 들어 있지 않다. 설치 명령 한 줄이면 되고, 그래야 최신 버전을 쓴다.

## 준비물

| 항목 | 필요 이유 | 비고 |
|---|---|---|
| Claude Code (또는 MCP 지원 클라이언트) | 에이전트 실행 | |
| `uv` | MCP 서버 실행 | https://docs.astral.sh/uv/ |
| 한컴오피스 (한글) | 검증 스크립트 | **Windows 전용.** 없으면 문서 편집은 되지만 검증은 못 한다 |

문서 편집 자체는 OS를 가리지 않는다. **검증 스크립트만 Windows + 한글 설치가 필요하다**(한글 실행 파일과 WinRT PDF 렌더러를 쓴다).

## 설치

### 에이전트에게 맡기려면 (가장 빠름)

아래를 그대로 복사해 Claude Code에 붙여넣는다. 이어지는 0~3단계를 에이전트가 대신 해준다.

```
hwpx-writing-kit.zip 을 이 프로젝트에 설치해줘.

1. zip 압축 풀기
2. 안에 있는 README.md 를 먼저 읽고 그 절차를 따를 것
3. skills/hwpx-editing 폴더를 .claude/skills/ 아래로 복사
4. mcp.json.example 을 프로젝트 루트에 .mcp.json 으로 복사
5. uv 가 설치돼 있는지 확인하고, 없으면 설치 명령을 알려줘

끝나면 내가 직접 해야 할 일(재시작 필요 여부)을 알려주고,
내 hwpx 파일을 하나 읽어서 연결이 됐는지 확인해줘.
```

### 0. uv 설치 (이미 있으면 건너뛴다)

```powershell
powershell -c "irm https://astral.sh/uv/install.ps1 | iex"
```

설치 후 터미널을 새로 열고 `uv --version`으로 확인한다.

> uv를 쓰고 싶지 않으면 `pip install hwpx-mcp-server`로 설치해도 된다. 이 경우 아래 `.mcp.json`의 `command`를 `"hwpx-mcp-server"`로, `args`를 `[]`로 바꾼다.

### 1. MCP 서버 연결

작업할 프로젝트 폴더 루트에 `mcp.json.example`을 `.mcp.json`으로 복사한다. Claude Code가 이 파일을 읽어 서버를 띄운다.

```powershell
Copy-Item mcp.json.example .mcp.json
```

`uvx`가 첫 실행 때 `hwpx-mcp-server`를 자동으로 내려받으므로 별도 설치 명령은 필요 없다. 미리 받아두려면 `uvx hwpx-mcp-server --help`를 한 번 실행한다.

### 2. 스킬 설치

`skills/hwpx-editing/` 폴더를 프로젝트의 `.claude/skills/` 아래로 복사한다.

```powershell
New-Item -ItemType Directory -Force .claude\skills | Out-Null
Copy-Item -Recurse skills\hwpx-editing .claude\skills\
```

Claude Code를 다시 시작하면 스킬이 자동 인식된다. 개인 전역으로 쓰려면 `~\.claude\skills\`에 넣어도 된다.

### 3. 확인

에이전트에게 hwpx 파일 하나를 읽어보게 한다. `get_document_info`가 문단 수와 표 개수를 돌려주면 연결된 것이다.

### 4. CLAUDE.md에 규칙 심기 (권장)

스킬은 관련 작업일 때 불려 오지만, **에이전트가 스킬을 부르지 않고 그냥 hwpx를 건드리는 경우**가 있다. 프로젝트의 `CLAUDE.md`에 최소 규칙을 박아두면 매 세션 자동으로 적용되어 이걸 막는다. 아래를 붙여넣는다.

```
이 프로젝트의 CLAUDE.md에 hwpx 작업 규칙을 추가해줘.
CLAUDE.md가 없으면 새로 만들어줘.

.claude/skills/hwpx-editing/SKILL.md 를 읽고, 거기서 아래 항목만 뽑아
10줄 이내로 간결하게 정리해 넣어줘. 원문을 통째로 복사하지 말 것.

- hwpx를 건드리기 전에 hwpx-editing 스킬을 먼저 읽어야 한다는 것
- hwpx는 통째로 재생성하지 말고 부분 치환만 한다는 것
- 고치기 전에 find_text 로 현재 상태를 확인한다는 것
- 수정 후 verify-hwpx.ps1 과 render-pdf.ps1 검증을 반드시 거친다는 것
- 쓰기 도구는 즉시 저장되므로 위험한 편집은 copy_document 사본에서 한다는 것

기존 CLAUDE.md 내용은 건드리지 말고 섹션 하나만 추가해줘.
```

## 작업 방식 — 핵심 원칙 3가지

**1. 원본은 Markdown, hwpx는 사본이다.**
내용은 항상 MD에서 먼저 고치고 그 결과를 hwpx에 반영한다. 반대 방향으로 작업하면 두 파일이 조용히 어긋난다.

**2. 재생성이 아니라 부분 치환이다.**
사람이 한글에서 직접 손본 내용이 hwpx에 들어 있다. MD 기준으로 전체를 다시 만들면 그게 전부 날아간다. 항상 해당 문단·셀만 골라 바꾼다.

**3. 고치기 전에 읽는다.**
`find_text`로 지금 hwpx에 실제로 뭐라고 적혀 있는지 확인한 다음 치환한다. MD 내용이 hwpx에도 그대로 있으리라 가정하면 매칭에 실패하거나 엉뚱한 곳을 바꾼다.

## 실제 작업 흐름

```
MD 원고 수정
   ↓
find_text 로 hwpx 현재 상태 확인
   ↓
copy_document 로 작업 사본 생성 (위험한 편집일 때)
   ↓
search_and_replace / set_table_cell_text 로 타깃 치환
   ↓
verify-hwpx.ps1  → 한글에서 열리는지 + PDF 변환
   ↓
render-pdf.ps1   → 바뀐 쪽만 PNG로 뽑아 눈으로 확인
```

마지막 두 단계를 건너뛰고 "완료"라고 하지 않는다. 이 키트에서 가장 중요한 부분이다.

## 작업 프롬프트

세션을 시작할 때 붙여넣는다.

```
.claude/skills/hwpx-editing/SKILL.md 를 먼저 읽고 그 규칙대로 작업해줘.

대상 파일: 원고.hwpx

반드시 지킬 것
- hwpx를 통째로 다시 만들지 말고, 고칠 부분만 찾아서 치환할 것
- 고치기 전에 find_text 로 지금 뭐라고 적혀 있는지 나에게 먼저 보여줄 것
- 수정 후 verify-hwpx.ps1 과 render-pdf.ps1 로 검증하고,
  뽑은 PNG를 직접 열어 확인한 다음 보고할 것

오늘 할 일: (여기에 작업 내용을 적는다)
```

검증만 따로 시킬 때는 이렇게 한다.

```
방금 수정한 원고.hwpx 를 검증해줘.
verify-hwpx.ps1 로 한글에서 열리는지 확인하고,
바뀐 3~5쪽을 render-pdf.ps1 로 PNG로 뽑아서
표 정렬이랑 쪽 넘김이 괜찮은지 직접 보고 알려줘.
```

**어떤 프롬프트를 쓰든 이 문장은 빼지 않는다.**

> hwpx를 통째로 다시 만들지 말고, 고칠 부분만 찾아서 치환할 것

에이전트가 원고를 재생성해 덮어쓰는 것이 이 작업의 1순위 사고이고, 사람이 한글에서 직접 손본 내용은 그렇게 사라진다.

Claude Code가 아닌 도구(Cursor, Codex 등)는 스킬을 자동 인식하지 못할 수 있다. 그때는 첫 줄의 `SKILL.md 를 먼저 읽고`를 반드시 남겨둔다.

## 검증

```powershell
# 열리는지 판정하고 PDF까지 뽑는다
.\.claude\skills\hwpx-editing\scripts\verify-hwpx.ps1 `
    -HwpxPath "원고.hwpx" -PdfPath "$env:TEMP\check.pdf"

# 바뀐 쪽만 PNG로 렌더 (반드시 powershell.exe = Windows PowerShell 5.1)
powershell.exe -NoProfile -File .\.claude\skills\hwpx-editing\scripts\render-pdf.ps1 `
    -PdfPath "$env:TEMP\check.pdf" -OutDir "$env:TEMP\png" -Pages "3-5"
```

`-Pages`는 `all`, `5`, `2-7`, `1,4,9-11` 형식을 받는다. 나온 PNG를 에이전트에게 읽히면 표 정렬과 쪽 넘김을 직접 보고 판단한다.

`verify-hwpx.ps1`은 설치된 한글을 자동으로 찾는다. 못 찾으면 `-HwpExe`로 경로를 직접 준다.

## 알려진 함정

| 함정 | 증상 | 대응 |
|---|---|---|
| **콜드 스타트 오탐** | 한글 첫 실행이 12초를 넘겨 뜨는 탓에, 고정 시간 대기 후 프로세스를 확인하면 **정상 파일이 깨진 것으로 판정된다** | 직접 판정 명령을 짜지 말고 `verify-hwpx.ps1`을 쓴다(워밍업 후 폴링한다) |
| **즉시 저장** | 수정 도구는 호출하는 순간 원본 파일에 저장된다. 미리보기나 되돌리기 단계가 없다 | 위험한 편집은 `copy_document` 사본에서 먼저 한다. `HWPX_MCP_AUTOBACKUP=1`이 `.bak`을 남기지만 여기에만 기대지 않는다 |
| **샌드박스 루트** | 서버를 띄운 폴더 밖 경로를 주면 `path is outside sandbox root`로 거부된다 | 프로젝트 상대경로를 쓴다 |
| **표 그리드 불일치** | 셀 폭만 바꾸면 한글이 행을 재배치해 행 전체가 깨진다 | 셀 폭은 열 그리드(`colAddr`/`colSpan`) 합산과 맞춘다 |
| **행 높이는 최소값** | 내용이 길어지면 행이 자라고, 넘치면 표가 통째로 다음 쪽으로 밀린다 | 높이는 소폭씩 조정하고 매번 렌더해서 확인한다 |
| **PowerShell 버전** | `render-pdf.ps1`을 `pwsh`(7)로 돌리면 WinRT 타입 로드에 실패한다 | `powershell.exe`(5.1)로 실행한다 |

## 문제 해결

**MCP 도구가 파일을 못 연다** — 서버가 `package validation failed`로 거부하면 Python `zipfile`로 `Contents/hwpx` 내부 XML을 직접 고치는 폴백이 있다. `SKILL.md`의 폴백 항목을 참고한다. 이때 백업 생성과 zip 항목 순서 유지가 중요하다.

**표 셀 치환이 안 먹는다** — 표 셀 텍스트는 여러 문단·run으로 쪼개져 저장되는 경우가 있다. 전역 문자열 치환 전에 내부 XML 문맥을 먼저 확인한다.

**레이아웃이 미세하게 어긋난다** — 스크린샷으로 픽셀을 추정하지 말고, 사람이 한글에서 직접 고쳐 저장한 파일을 unzip해 실제 수치(`cellSz`, `colSpan`)를 꺼내 이식한다. 사람이 손본 파일이 가장 정확한 사양이다.

## 출처와 라이선스

- MCP 서버 **hwpx-mcp-server** (Apache-2.0) — https://github.com/airmang/hwpx-mcp-server
- 기반 라이브러리 **python-hwpx** — https://github.com/airmang/python-hwpx

이 키트의 문서와 PowerShell 스크립트는 자유롭게 수정해 쓰면 된다.

**검증 범위.** 두 PowerShell 스크립트와 함정 목록(특히 콜드 스타트 오탐)은 한컴오피스 2020 + Windows 11에서 15쪽 분량 hwpx로 직접 실행해 확인했다. MCP 서버 설치 절차(`uv`/`uvx`)는 서버 배포처의 공식 안내를 옮긴 것으로, 이 키트를 만든 환경에서는 별도 방식으로 서버를 띄우고 있어 그대로 실행해보지는 않았다. 다른 한글 버전에서는 경로와 동작이 다를 수 있다.
